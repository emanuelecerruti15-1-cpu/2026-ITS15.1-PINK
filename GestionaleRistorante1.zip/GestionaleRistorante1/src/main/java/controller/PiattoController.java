package controller;

import java.util.List;
import model.Piatto;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import service.PiattoService;

/**
 * Controller REST per la gestione dei piatti.
 *
 * Questa classe collega:
 * - frontend JavaScript
 * - logica Java del gestionale
 * - PiattoService
 *
 * Per ora usa dati in memoria, quindi non serve ancora il database.
 */
@RestController
@RequestMapping("/api/piatti")
@CrossOrigin(origins = "*")
public class PiattoController {

    /**
     * Service che contiene la logica dei piatti.
     */
    private final PiattoService piattoService = new PiattoService();

    /**
     * Restituisce tutti i piatti del menu.
     *
     * GET http://localhost:8080/api/piatti
     */
    @GetMapping
    public List<Piatto> getTuttiIPiatti() {
        return piattoService.getTuttiIPiatti();
    }

    /**
     * Restituisce un singolo piatto tramite id.
     *
     * GET http://localhost:8080/api/piatti/1
     */
    @GetMapping("/{id}")
    public Piatto getPiattoById(@PathVariable("id") Long id) {
        return piattoService.getPiattoById(id);
    }

    /**
     * Crea un nuovo piatto.
     *
     * POST http://localhost:8080/api/piatti
     */
    @PostMapping
    public Piatto creaPiatto(@RequestBody Piatto piatto) {
        return piattoService.creaPiatto(
                piatto.getNome(),
                piatto.getPrezzo(),
                piatto.isDisponibile()
        );
    }

    /**
     * Modifica un piatto esistente.
     *
     * PUT http://localhost:8080/api/piatti/1
     */
    @PutMapping("/{id}")
    public Piatto modificaPiatto(@PathVariable("id") Long id, @RequestBody Piatto piatto) {
        return piattoService.modificaPiatto(
                id,
                piatto.getNome(),
                piatto.getPrezzo(),
                piatto.isDisponibile()
        );
    }

    /**
     * Elimina un piatto.
     *
     * DELETE http://localhost:8080/api/piatti/1
     */
    @DeleteMapping("/{id}")
    public void eliminaPiatto(@PathVariable("id") Long id) {
        piattoService.eliminaPiatto(id);
    }
}