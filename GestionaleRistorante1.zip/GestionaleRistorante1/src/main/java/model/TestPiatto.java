/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import model.Piatto;

public class TestPiatto {

    public static void main(String[] args) {

        Piatto piatto1 = new Piatto();

        piatto1.setId(1L);
        piatto1.setNome("Pizza Margherita");
        piatto1.setPrezzo(8.50);
        piatto1.setDisponibile(true);

        System.out.println("ID: " + piatto1.getId());
        System.out.println("Nome: " + piatto1.getNome());
        System.out.println("Prezzo: " + piatto1.getPrezzo());
        System.out.println("Disponibile: " + piatto1.isDisponibile());
    }
}