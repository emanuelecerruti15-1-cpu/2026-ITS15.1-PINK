/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package service;

import java.util.ArrayList;
import java.util.List;
import model.Piatto;

/**
 * Classe che gestisce la logica dei piatti del menu.
 *
 * Per ora NON usiamo database.
 * I piatti vengono salvati dentro una lista in memoria.
 *
 * Questa classe serve per:
 * - creare piatti
 * - visualizzare tutti i piatti
 * - cercare un piatto tramite id
 * - modificare un piatto
 * - eliminare un piatto
 */
public class PiattoService {

    /**
     * Lista che contiene tutti i piatti.
     * Per ora sostituisce temporaneamente il database.
     */
    private List<Piatto> piatti;

    /**
     * Variabile usata per generare automaticamente gli id dei piatti.
     * Ogni volta che creo un piatto, aumento questo numero.
     */
    private Long prossimoId;

    /**
     * Costruttore del service.
     *
     * Quando creo un oggetto PiattoService,
     * inizializzo la lista dei piatti e inserisco alcuni piatti di esempio.
     */
    public PiattoService() {
        this.piatti = new ArrayList<>();
        this.prossimoId = 1L;

        // Piatti iniziali di esempio
        creaPiatto("Pizza Margherita", 8.00, true);
        creaPiatto("Spaghetti Carbonara", 12.00, true);
        creaPiatto("Tiramisù", 6.00, true);
    }

    /**
     * Restituisce tutti i piatti presenti nel menu.
     *
     * @return lista completa dei piatti
     */
    public List<Piatto> getTuttiIPiatti() {
        return piatti;
    }

    /**
     * Cerca un piatto tramite il suo id.
     *
     * @param id id del piatto da cercare
     * @return il piatto trovato
     *
     * Se il piatto non esiste, viene generato un errore.
     */
    public Piatto getPiattoById(Long id) {
        for (Piatto piatto : piatti) {
            if (piatto.getId().equals(id)) {
                return piatto;
            }
        }

        throw new IllegalArgumentException("Piatto non trovato con id: " + id);
    }

    /**
     * Crea un nuovo piatto e lo aggiunge alla lista.
     *
     * @param nome nome del piatto
     * @param prezzo prezzo del piatto
     * @param disponibile true se il piatto è disponibile, false se non lo è
     * @return il piatto appena creato
     */
    public Piatto creaPiatto(String nome, double prezzo, boolean disponibile) {

        // Controllo dati prima di creare il piatto
        validaNome(nome);
        validaPrezzo(prezzo);

        // Creo il nuovo oggetto Piatto
        Piatto nuovoPiatto = new Piatto();

        // Assegno automaticamente un id
        nuovoPiatto.setId(prossimoId);

        // Aumento l'id per il prossimo piatto che verrà creato
        prossimoId++;

        // Imposto i dati del piatto
        nuovoPiatto.setNome(nome);
        nuovoPiatto.setPrezzo(prezzo);
        nuovoPiatto.setDisponibile(disponibile);

        // Aggiungo il piatto alla lista
        piatti.add(nuovoPiatto);

        // Restituisco il piatto creato
        return nuovoPiatto;
    }

    /**
     * Modifica un piatto già esistente.
     *
     * @param id id del piatto da modificare
     * @param nome nuovo nome
     * @param prezzo nuovo prezzo
     * @param disponibile nuova disponibilità
     * @return il piatto modificato
     */
    public Piatto modificaPiatto(Long id, String nome, double prezzo, boolean disponibile) {

        // Controllo dati prima della modifica
        validaNome(nome);
        validaPrezzo(prezzo);

        // Cerco il piatto da modificare
        Piatto piatto = getPiattoById(id);

        // Aggiorno i dati
        piatto.setNome(nome);
        piatto.setPrezzo(prezzo);
        piatto.setDisponibile(disponibile);

        // Restituisco il piatto aggiornato
        return piatto;
    }

    /**
     * Elimina un piatto dalla lista.
     *
     * @param id id del piatto da eliminare
     */
    public void eliminaPiatto(Long id) {

        // Cerco il piatto da eliminare
        Piatto piatto = getPiattoById(id);

        // Rimuovo il piatto dalla lista
        piatti.remove(piatto);
    }

    /**
     * Cambia la disponibilità di un piatto.
     *
     * Esempio:
     * - disponibile = true  → il piatto può essere ordinato
     * - disponibile = false → il piatto non può essere ordinato
     *
     * @param id id del piatto
     * @param disponibile nuova disponibilità
     * @return il piatto aggiornato
     */
    public Piatto cambiaDisponibilita(Long id, boolean disponibile) {

        // Cerco il piatto
        Piatto piatto = getPiattoById(id);

        // Cambio la disponibilità
        piatto.setDisponibile(disponibile);

        // Restituisco il piatto aggiornato
        return piatto;
    }

    /**
     * Controlla se un piatto può essere ordinato.
     *
     * @param id id del piatto da controllare
     * @return true se disponibile, false se non disponibile
     */
    public boolean piattoDisponibile(Long id) {

        // Cerco il piatto
        Piatto piatto = getPiattoById(id);

        // Ritorno il valore del campo disponibile
        return piatto.isDisponibile();
    }

    /**
     * Metodo privato per validare il nome del piatto.
     *
     * Il nome non può essere:
     * - null
     * - vuoto
     * - composto solo da spazi
     *
     * @param nome nome da controllare
     */
    private void validaNome(String nome) {
        if (nome == null || nome.trim().isEmpty()) {
            throw new IllegalArgumentException("Il nome del piatto è obbligatorio.");
        }
    }

    /**
     * Metodo privato per validare il prezzo del piatto.
     *
     * Il prezzo deve essere maggiore di zero.
     *
     * @param prezzo prezzo da controllare
     */
    private void validaPrezzo(double prezzo) {
        if (prezzo <= 0) {
            throw new IllegalArgumentException("Il prezzo del piatto deve essere maggiore di zero.");
        }
    }
}