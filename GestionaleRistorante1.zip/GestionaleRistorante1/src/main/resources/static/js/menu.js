/* ================================================================
   LOGICA PAGINA MENU — CRUD piatti (nome + prezzo)
   ================================================================ */

const PIATTI_DEMO = [
    { id: 1, nome: 'Pizza Margherita', prezzo: 8, disponibile: true },
    { id: 2, nome: 'Spaghetti Carbonara', prezzo: 12, disponibile: true },
    { id: 3, nome: 'Insalata mista', prezzo: 9.25, disponibile: true },
    { id: 4, nome: 'Tiramisù', prezzo: 6, disponibile: true },
    { id: 5, nome: 'Cotoletta alla Milanese', prezzo: 14, disponibile: true }
];

let piatti = [];
let backendConnesso = true;

document.addEventListener('DOMContentLoaded', init);

async function init() {
    try {
        piatti = await getPiatti();
    } catch (e) {
        backendConnesso = false;
        piatti = PIATTI_DEMO;
        mostraAvviso('Modalità demo: collega il backend per dati reali.');
        console.error(e);
    }

    renderTabella();

    document.getElementById('form-piatto').addEventListener('submit', salvaPiatto);
    document.getElementById('btn-annulla').addEventListener('click', resetForm);
}

function renderTabella() {
    const tbody = document.getElementById('tabella-piatti');

    if (!piatti || piatti.length === 0) {
        tbody.innerHTML = '<tr><td colspan="4">Nessun piatto presente.</td></tr>';
        return;
    }

    tbody.innerHTML = piatti.map(function (p) {
        const stato = p.disponibile !== false ? 'Disponibile' : 'Non disp.';

        return '<tr>' +
            '<td>' + escapeHtml(p.nome) + '</td>' +
            '<td>' + formattaEuro(p.prezzo) + '</td>' +
            '<td>' + stato + '</td>' +
            '<td class="data-table__actions">' +
                '<button type="button" class="link-btn" data-edit="' + p.id + '">Modifica</button>' +
                '<button type="button" class="link-btn link-btn--muted" data-del="' + p.id + '">Elimina</button>' +
            '</td>' +
        '</tr>';
    }).join('');

    tbody.querySelectorAll('[data-edit]').forEach(function (b) {
        b.addEventListener('click', function () {
            modifica(b.dataset.edit);
        });
    });

    tbody.querySelectorAll('[data-del]').forEach(function (b) {
        b.addEventListener('click', function () {
            elimina(b.dataset.del);
        });
    });
}

function modifica(id) {
    const p = trovaPiatto(id);

    if (!p) {
        alert('Piatto non trovato.');
        return;
    }

    document.getElementById('form-titolo').textContent = 'Modifica piatto';
    document.getElementById('piatto-id').value = p.id;
    document.getElementById('piatto-nome').value = p.nome;
    document.getElementById('piatto-prezzo').value = p.prezzo;
    document.getElementById('piatto-disponibile').value = String(p.disponibile !== false);

    document.getElementById('btn-annulla').classList.remove('is-hidden');
    document.getElementById('gruppo-disponibile').classList.remove('is-hidden');
}

function resetForm() {
    document.getElementById('form-titolo').textContent = 'Aggiungi piatto';
    document.getElementById('form-piatto').reset();
    document.getElementById('piatto-id').value = '';

    document.getElementById('btn-annulla').classList.add('is-hidden');
    document.getElementById('gruppo-disponibile').classList.add('is-hidden');
}

async function salvaPiatto(e) {
    e.preventDefault();

    const id = document.getElementById('piatto-id').value;
    const nome = document.getElementById('piatto-nome').value.trim();
    const prezzo = Number(document.getElementById('piatto-prezzo').value);
    const disp = document.getElementById('piatto-disponibile').value === 'true';

    if (!nome) {
        alert('Inserisci il nome del piatto.');
        return;
    }

    if (Number.isNaN(prezzo) || prezzo <= 0) {
        alert('Inserisci un prezzo valido.');
        return;
    }

    const piatto = {
        nome: nome,
        prezzo: prezzo,
        disponibile: disp
    };

    try {
        if (id) {
            await modificaPiatto(id, piatto);
        } else {
            await creaPiatto(piatto);
        }

        piatti = await getPiatti();
        renderTabella();
        resetForm();

    } catch (err) {
    console.error(err);
    alert('Errore reale salvataggio: ' + err.message);
    }
}

async function elimina(id) {
    const p = trovaPiatto(id);

    if (!p) {
        alert('Piatto non trovato.');
        return;
    }

    if (!confirm('Eliminare questo piatto dal menu?')) return;

    try {
        await eliminaPiatto(id);

        piatti = await getPiatti();
        renderTabella();
        resetForm();

    } catch (e) {
    console.error(e);
    alert('Errore reale eliminazione: ' + e.message);
}
}

function trovaPiatto(id) {
    return piatti.find(function (x) {
        return String(x.id) === String(id);
    });
}

function mostraAvviso(msg) {
    const el = document.getElementById('api-notice');

    if (!el) return;

    el.textContent = msg;
    el.classList.remove('is-hidden');
}

function escapeHtml(testo) {
    return String(testo)
        .replaceAll('&', '&amp;')
        .replaceAll('<', '&lt;')
        .replaceAll('>', '&gt;')
        .replaceAll('"', '&quot;')
        .replaceAll("'", '&#039;');
}